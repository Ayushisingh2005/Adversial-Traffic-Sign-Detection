# Adversarial Attack Detection for Traffic Sign Recognition

CNN classifier + adversarial detector + Grad-CAM explainability, evaluated
under both standard and adaptive threat models on GTSRB.

## Setup

```bash
git clone <your-repo-url>
cd adversarial-traffic-sign-detection
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

GTSRB downloads automatically on first run (~300 MB). If torchvision's
download fails (it sometimes does), fetch the archives manually from the
GTSRB benchmark site and place them under `data/gtsrb/`.

## Run order

Each stage depends on the previous one.

```bash
# Stage 1 — base classifier (~20 min GPU, ~2 h CPU)
python -m src.train_classifier

# Stage 2 — generate adversarial examples (4 attacks)
python -m src.generate_attacks

# Stage 3 — train the detector
python -m src.train_detector

# Stage 4 — adaptive attack (attacker knows the detector)
python -m src.adaptive_attack

# Stage 5 — metrics + comparison table
python -m src.evaluate

# Demo
streamlit run app/streamlit_app.py
```

On CPU, lower `N_ATTACK_SAMPLES` in `config.py` to ~300 and drop
`CW_STEPS` to 20 — C&W and Square are the slow ones.

## What each module does

| File | Role |
|---|---|
| `src/data.py` | GTSRB / CIFAR-10 loaders, [0,1] range (required by torchattacks) |
| `src/models.py` | Classifier, detector, normalisation wrapper, Grad-CAM |
| `src/train_classifier.py` | Stage 1 |
| `src/generate_attacks.py` | FGSM, PGD, C&W, Square via torchattacks |
| `src/train_detector.py` | The core contribution |
| `src/baseline_squeeze.py` | Feature Squeezing comparison baseline |
| `src/adaptive_attack.py` | Joint classifier-fool + detector-evade PGD |
| `src/evaluate.py` | Accuracy / precision / recall / F1 / ROC-AUC tables |
| `app/streamlit_app.py` | Demo UI |

## Testing

**1. Classifier sanity check** — `train_classifier.py` prints final clean test
accuracy. Target ≥ 0.97 on GTSRB. Below 0.90 means something is wrong with
the data pipeline.

**2. Attack sanity check** — `generate_attacks.py` prints `clean_acc` and
`adv_acc` per attack. A working attack pushes `adv_acc` near 0 while
`mean_Linf` stays ≤ ε. If `adv_acc` stays high, the attack isn't landing —
usually a normalisation bug.

**3. Detector check** — target ≥ 0.90 validation accuracy. Also run the
leave-one-attack-out test, which is what reviewers will ask about:

```bash
python -m src.train_detector --holdout cw --out checkpoints/det_no_cw.pt
```

Then evaluate on C&W only. A large gap means the detector memorised attack
signatures rather than learning a general notion of "perturbed".

**4. Adaptive attack check** — `adaptive_attack.py` prints detector recall
under attack. Expect a meaningful drop from the non-adaptive number. That
drop *is* the finding; a detector showing no drop usually means λ is too low
or the attack didn't converge.

**5. Baseline comparison** — `evaluate.py` writes
`results/detection_results.csv` with both methods side by side. This table
goes straight into the paper.

**6. Demo check** — upload a clean GTSRB image (should read CLEAN), then set
the sidebar attack to PGD (should flip to ADVERSARIAL). Sweep ε from 1/255 to
16/255 to find where detection starts failing.

## Deployment

**Streamlit Community Cloud** (free, easiest for a demo link):
push to a public GitHub repo, connect it at share.streamlit.io, set the main
file to `app/streamlit_app.py`. Checkpoints are too large for plain git —
either use Git LFS or host the `.pt` files on Hugging Face Hub and download
them at startup. Community Cloud is CPU-only, so live C&W/Square in the demo
will be slow; consider restricting the sidebar to FGSM and PGD in production.

**Hugging Face Spaces** — better option since model files live in the same
repo natively. Create a Space with the Streamlit SDK, push the code plus
checkpoints, add a `requirements.txt`. Free tier is CPU; paid tiers give GPU.

**Local (what you'll actually demo to your mentor)** — just
`streamlit run app/streamlit_app.py`. No upload limits, no cold starts, GPU
available. Most reliable for a live viva. Have the cloud link as a backup.

## Notes

- Attacks come from `torchattacks`, not custom code — the contribution is the
  detector, not the attack implementations.
- Normalisation lives inside `NormalizedModel`, not in the transforms. This is
  deliberate: attacks must operate in valid [0,1] pixel space.
- Set `DATASET = "cifar10"` in `config.py` and re-run the pipeline for the
  generalisation experiment.
